package fileHandling;

import java.io.*;
import java.util.*;

public class file {
	
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);

		File f = new File("JavaFile1.txt");
		FileWriter fw1 = new FileWriter(f);
		fw1.write("Java is an object-oriented programming language.\n");
		fw1.write("It supports encapsulation, inheritance, and polymorphism.\n");
		fw1.write("File handling in Java allows for efficient reading and searching of text.\n");
		fw1.write("Keep learning and mastering Java!\n");
		fw1.close();
		System.out.println("JavaFile1.txt created and written successfully.");

		System.out.println("\nContents of JavaFile1.txt:");
		BufferedReader reader1 = new BufferedReader(new FileReader(f));
		String line;
		while ((line = reader1.readLine()) != null) {
			System.out.println(line);
		}
		reader1.close();

		String file2 = "JavaFile2.txt";
		FileWriter fw2 = new FileWriter(file2);
		fw2.write("This is the first line in this JavaFile2.txt file.\n");
		fw2.close();
		System.out.println("\nJavaFile2.txt created with initial content.");

		BufferedReader readerCopy = new BufferedReader(new FileReader(f));
		FileWriter fwAppend = new FileWriter(file2, true); // true for append mode
		while ((line = readerCopy.readLine()) != null) {
			fwAppend.write(line + "\n");
		}
		readerCopy.close();
		fwAppend.close();
		System.out.println("Content from JavaFile1.txt copied to JavaFile2.txt.");

		BufferedReader analyzer = new BufferedReader(new FileReader(f));
		int charCount = 0, wordCount = 0, lineCount = 0, polyCount = 0;
		List<Integer> polyLineNumbers = new ArrayList<>();
		String searchWord = "polymorphism";
		int currentLine = 0;

		String current;
		while ((current = analyzer.readLine()) != null) {
			currentLine++;
			lineCount++;
			charCount += current.length();
			String[] words = current.split("\\s+");
			wordCount += words.length;

			if (current.toLowerCase().contains(searchWord)) {
				polyLineNumbers.add(currentLine);

				for (String w : words) {
					if (w.equalsIgnoreCase(searchWord)) {
						polyCount++;
					}
				}
			}
		}
		analyzer.close();

		System.out.println("\nAnalysis of JavaFile1.txt:");
		System.out.println("Total Characters: " + charCount);
		System.out.println("Total Lines: " + lineCount);
		System.out.println("Total Words: " + wordCount);
		System.out.println("Occurrences of \"polymorphism\": " + polyCount);
		if (!polyLineNumbers.isEmpty()) {
			System.out.print("Found \"polymorphism\" at line(s): ");
			for (int i : polyLineNumbers) {
				System.out.print(i + " ");
			}
			System.out.println();
		} else {
			System.out.println("\"polymorphism\" not found in the file.");
		}
	}
}
